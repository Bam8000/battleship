package battleship;

public class cell {

}
